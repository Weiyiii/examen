## Samenvatting
![samenvatting](https://github.com/siwaipang/kt2yeetwat/blob/main/photos/samenvatting.png)

## Maak eerst de kwaliteitshandboek

 ! betekent dat het in de planning MOET staan
 
 ![kwaliteitshandboek](https://github.com/siwaipang/kt2yeetwat/blob/main/photos/kwaliteitshandboek.png)
 
 Bij kop 'Realisatie' moet je dezelfde punten invullen bij de onderdelen. Schrijf gelijk op hoe laat je klaar bent.
 
 Bij 'Wijzigingen na de test' schrijf je op welke bestanden je gewijzigd hebt nadat je het programma hebt getest
 
 ## Maak de testplan
  ![testvoorbereiding](https://github.com/siwaipang/kt2yeetwat/blob/main/photos/testvoorbereiding.png)

  Welke onderdelen van de applicatie moeten getest worden. Vul dat hier in.

  ![testvoorbereiding 2](https://github.com/siwaipang/kt2yeetwat/blob/main/photos/testvoorbereiding2.png)

  Vul hier alleen de problemen in.
  
  ![testlog](https://github.com/siwaipang/kt2yeetwat/blob/main/photos/testlog.png)
